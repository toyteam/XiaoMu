<?php $__env->startSection('css'); ?>

<link href="http://cdn.bootcss.com/wangeditor/2.1.20/css/wangEditor.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

        <div class="col-md-9 col-sm-7 col-xs-12">
            <div class="mb-block write">
                <div class="mb-block-content">
                    <table class="table">
                        <tr>
                            <th>名称</th>
                            <th>文章数目</th>
                            <th>描述</th>
                            <th width="20%">操作</th>
                        </tr>
                        <?php if(isset($categorys)): ?>
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td id="name_<?php echo e($category->id); ?>" class="black"><?php echo e($category->category_name); ?></td>
                            <td id="count_<?php echo e($category->id); ?>"><?php echo e($category->blog_count); ?></td>
                            <td id="desc_<?php echo e($category->id); ?>"><?php echo e($category->category_desc); ?></td>
                            <td>
                                <a href="<?php echo e(url('blog/manage/category/delete')); ?>?id=<?php echo e($category->id); ?>" class="btn btn-danger btn-xs">删除</a>
                                <button class="btn btn-info btn-xs edit" value="<?php echo e($category->id); ?>">编辑</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                    <button id="add" class="btn btn-success">添加分类</button>
                </div>

            </div>
        </div>
<button id="modal-edit" class="btn hidden" data-toggle="modal" data-target="#myModal"></button>
<form class="form-horizontal form-label-left" action="<?php echo e(url('blog/manage/category/edit')); ?>" method="post">
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        &times;
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                        编辑分类信息
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">分类名称</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input class="form-control col-md-7 col-xs-12" type="text" id="edit_name" name="category_name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">分类描述</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea class="form-control col-md-7 col-xs-12" id="edit_desc" name="category_desc"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="edit_id" value="" name="id"/>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal -->
    </div>
</form>
<button id="modal-add" class="btn hidden" data-toggle="modal" data-target="#myModal2"></button>
<form class="form-horizontal form-label-left" action="<?php echo e(url('blog/manage/category/add')); ?>" method="post">
    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        &times;
                    </button>
                    <h4 class="modal-title" id="myModalLabel">
                        添加分类
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">分类名称</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input class="form-control col-md-7 col-xs-12" type="text" name="category_name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">分类描述</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea class="form-control col-md-7 col-xs-12" name="category_desc"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                    <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                    <button type="submit" class="btn btn-primary">添加</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal -->
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    $(document).ready(function() {

        $('#add').click(function() {
            $('#modal-add').click();
        });

        $('.edit').click(function() {
            var id = $(this).val();
            $('#edit_name').val($('#name_'+id).text());
            $('#edit_desc').val($('#desc_'+id).text());
            $('#edit_id').val(id);
            $('#modal-edit').click();
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('commen.blogmanage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>