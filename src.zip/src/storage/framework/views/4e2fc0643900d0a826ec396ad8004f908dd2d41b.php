<?php $__env->startSection('css'); ?>

<link href="http://cdn.bootcss.com/wangeditor/2.1.20/css/wangEditor.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

        <div class="col-md-9 col-sm-7 col-xs-12">
            <div class="mb-block write">
                <div class="mb-block-content">
                        <form action="<?php echo e(url('blog/manage/write')); ?>" method="post">
                            <div class="form-group">
                                <label class="control-label">标题</label>
                                <input type="text" name="title" placeholder="请输入标题..." class="form-control" autocomplete="off" required="">
                            </div>
                            <div class="form-group">
                                <label class="control-label">分类</label>
                                <select class="form-control" name="category">
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="control-label">标签</label>
                                <input type="text" name="tag" placeholder="请输入标签(每个标签之间以逗号分隔)" class="form-control" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label class="control-label">正文</label>
                                <textarea name="content" id="textarea1" style="height: 500px;"></textarea>
                            </div>
                            
                            <br>
                            <br>

                            <label class="control-label pull-left">高级选项</label>
                            <hr>

                            <div class="form-group">
                                <label class="control-label">访问密码</label>
                                <input type="text" name="password" placeholder="请设置访问密码" class="form-control" autocomplete="off">
                            </div>

                            <div class="form-group">
                                <label class="control-label">文章摘要</label>
                                <textarea name="summary" rows="7" class="form-control" placeholder="如果此项为空，则默认截取文章前200个字作为摘要"></textarea>
                            </div><!-- 
                            <div class="form-group">
                                <label class="control-label">上传附件</label>
                                <input type="file" multiple="" name="file[]" class="form-control">
                            </div> -->
                            <div class="form-group">
                                <div class="checkbox">
                                    <label class="control-label"><input type="checkbox" name="index_top"> 首页置顶 </label>
                                    <label class="control-label"><input type="checkbox" name="category_top"> 分类置顶 </label>
                                    <label class="control-label"><input type="checkbox" name="allow_comment" checked> 允许评论 </label>
                                    <label class="control-label"><input type="checkbox" name="is_public"> 仅自己可见</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <input type="hidden" name="type" id="type" value="">
                                <input type="hidden" name="id" id="id" value="<?php echo e($id); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button value="1" class="btn-submit pull-left">发布博客</button>
                                <button value="2" class="btn-submit pull-left">保存草稿</button>
                            </div>
                            <br>
                        </form>                    
                </div>

            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="http://cdn.bootcss.com/wangeditor/2.1.20/js/lib/jquery-1.10.2.min.js"></script>
<script src="http://cdn.bootcss.com/wangeditor/2.1.20/js/wangEditor.js"></script>
    <script>
        var editor = new wangEditor('textarea1');
        editor.config.menuFixed = false;
        editor.config.menus = [
            'source',
            '|',
            'bold',
            'underline',
            'italic',
            'strikethrough',
            'eraser',
            'forecolor',
            'bgcolor',
            '|',
            'quote',
            'fontfamily',
            'fontsize',
            // 'head',
            // 'unorderlist',
            'orderlist',
            'alignleft',
            'aligncenter',
            'alignright',
            '|',
            'link',
            'unlink',
            'table',
            'emotion',
            '|',
            'img',
            'video',
            'location',
            'insertcode',
            '|',
            'undo',
            'redo',
            'fullscreen'
        ];
        editor.config.uploadImgUrl = '<?php echo e(url('upload_image')); ?>';
        editor.config.uploadParams = {
            '_token':"<?php echo e(csrf_token()); ?>",
            'id': <?php echo e($id); ?>

        };
        editor.config.uploadImgFileName = 'file';
        editor.config.uploadHeaders = {
            'Accept' : 'text/x-json'
        };
        editor.config.emotions = {
            'default': {
                title: '默认',
                data: 'http://www.wangeditor.com/wangEditor/test/emotions.data'
            }
        }

        editor.create();
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.btn-submit').click(function(e) {
                var val = $(e.target).val();
                $('#type').val(val);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('commen.blogmanage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>