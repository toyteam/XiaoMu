<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('')); ?>fileinput/css/fileinput.css" rel="stylesheet">
<style>
    .tab-div{
        min-height:400px;
    }
</style>
<style>

.kv-avatar .file-input {
    display: table-cell;
    max-width: 220px;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('col'); ?>
            <div class="col-md-12">
                <div class="mb-block">
                    <div class="panel-body">
                        <div class="col-md-12">
                            <div class="tabcordion">
                                <ul class="nav nav-tabs">
                                    
                                    <li class="active"><a data-target="#article" href="#">文章</a></li>
                                    
                                    <li><a data-target="#user_follow" href="#">他关注的人</a></li>
                                    <li><a data-target="#follow_user" href="#">关注他的人</a></li>
                                    <li><a data-target="#message" href="#">留言</a></li>
                                    <li><a data-target="#profile" href="#">个人信息</a></li>
                                </ul>

                                <div class="tab-content">

                                    <div id="article" class="active in tab-div">
                                        <ul class="list-group">
                                            <?php if(isset($blogs) && count($blogs) > 0): ?>
                                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-item">
                                                    <div class="article-title">
                                                        <a href="<?php echo e(url('blog')); ?>?id=<?php echo e($blog->id); ?>"><?php echo e($blog->blog_title); ?></a>
                                                    </div>
                                                    <div class="article-brief">
                                                        <?php echo $blog->blog_summary; ?>

                                                    </div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <li class="list-item">
                                                <center>博主尚未发布任何文章</center>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>

                                    <div id="user_follow" class=" tab-div">
                                        <ul class="list-group">
                                            <?php if(isset($user_follow) && count($user_follow) > 0): ?>
                                            <?php $__currentLoopData = $user_follow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-item"> 
                                                <div class="user">
                                                    <img src="<?php echo e($user->user_image_path); ?>" class="img-circle">&nbsp;
                                                    <span class="after-img-info">
                                                        <div class="user-name-sm"><?php echo e($user->user_name); ?></div>
                                                        <div class="user-bio-sm"><?php echo e($user->user_desc); ?></div>
                                                    </span>
                                                </div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <li class="list-item">
                                                <center>博主尚未关注任何人</center>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>

                                    <div id="follow_user" class=" tab-div">
                                        <ul class="list-group">
                                            <?php if(isset($follow_user) && count($follow_user) > 0): ?>
                                            <?php $__currentLoopData = $follow_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-item"> 
                                                <div class="user">
                                                    <img src="<?php echo e($user->user_image_path); ?>" class="img-circle">&nbsp;
                                                    <span class="after-img-info">
                                                        <div class="user-name-sm"><?php echo e($user->user_name); ?></div>
                                                        <div class="user-bio-sm"><?php echo e($user->user_desc); ?></div>
                                                    </span>
                                                </div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <li class="list-item">
                                                <center>尚未有任何人关注博主</center>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>

                                    <div id="message" class=" tab-div" style="max-height: 600px; overflow:auto;">
                                        <ul class="list-group">
                                            <?php if(isset($messages) && count($messages) > 0): ?>
                                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-item"> 
                                                <div class="user">
                                                    <img src="<?php echo e($user->user_image_path); ?>" class="img-circle">&nbsp;
                                                    <span class="after-img-info">
                                                        <div class="user-name-sm"><?php echo e($user->user_name); ?></div>
                                                        <div class="user-bio-sm"><?php echo e($user->user_desc); ?></div>
                                                    </span>
                                                </div>
                                                <div><?php echo e($message->message_content); ?></div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <li class="list-item">
                                                <center>尚未有任何人给博主留言</center>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>

                                    <div id="profile" class=" tab-div" style="max-height: 600px;">
                                        <ul class="list-group">
                                            &nbsp;&nbsp;&nbsp;&nbsp;
                                            <li class=""> 
                                                <form class="form-horizontal form-label-left">
                                                    <div class="form-group">
                                                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">用户名</label>
                                                        <div class="col-md-6 col-sm-6 col-xs-12" width="200px;">
                                                            <input id="avatar-1" name="avatar-1" type="file" class="file-loading">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">用户名</label>
                                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                                            <input class="form-control col-md-7 col-xs-12" type="text" name="user_name">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">密码</label>
                                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                                            <input class="form-control col-md-7 col-xs-12" type="password" name="user_password">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">邮箱</label>
                                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                                            <input class="form-control col-md-7 col-xs-12" type="email" name="user_email">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">手机</label>
                                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                                            <input class="form-control col-md-7 col-xs-12" type="user_phone" name="user_phone">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">QQ</label>
                                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                                            <input class="form-control col-md-7 col-xs-12" type="user_qq" name="user_qq">
                                                        </div>
                                                    </div>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('')); ?>tabcordion/tabcordion.js"></script>
<script src="<?php echo e(asset('')); ?>fileinput/js/fileinput.js"></script>
<script>
    $('.tabcordion').tabcordion();
</script>
<script>
$("#avatar-1").fileinput({
    overwriteInitial: true,
    maxFileSize: 1500,
    showClose: false,
    showCaption: false,
    showRemove: false,
    showUpload: false,
    showBrowse: false,
    browseOnZoneClick: true,
    defaultPreviewContent: '<img src="<?php echo e($user_info->user_image_path); ?>" alt="用户头像" style="width:160px">',
    allowedFileExtensions: ["jpg", "png", "gif"]
}).on("filebatchselected", function(event, files) {
            $(this).fileinput("upload");
        }).on("fileuploaded", function(event, data) {
          if(data.response)
          {
            location.reload(true);
          }
        });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('commen.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>