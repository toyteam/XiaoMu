<?php $__env->startSection('css'); ?>

<link href="http://cdn.bootcss.com/wangeditor/2.1.20/css/wangEditor.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

        <div class="col-md-9 col-sm-7 col-xs-12">
            <div class="mb-block write">
                <div class="mb-block-content">
                    <div class="list-blog">
                    
                    <?php if(isset($blogs)): ?>
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-item">
                                <h4><input type="checkbox" name="many"> <a class="black" href="<?php echo e(url('blog')); ?>?id=<?php echo e($blog->blog_id); ?>"><?php echo e($blog->blog_title); ?></a></h4>
                                <div class="item-category col-md-6 col-sm-6 col-xs-12"><?php echo e($blog->category_name); ?></div>
                                <div class="item-tag col-md-6 col-sm-6 col-xs-12"><?php echo e($blog->blog_tags); ?></div>
                                <div class="item-content col-md-12 col-xs-12 col-sm-12">
                                    <?php echo e($blog->blog_summary); ?>...
                                </div>
                                <div class="item-bottom  col-md-12 col-xs-12 col-sm-12">
                                    <a href="<?php echo e(url('blog')); ?>?id=<?php echo e($blog->blog_id); ?>">查看(<?php echo e($blog->blog_view_count); ?>)</a>
                                    <a href="<?php echo e(url('blog')); ?>?id=<?php echo e($blog->blog_id); ?>#comment">评论(<?php echo e($blog->comment_count); ?>)</a>
                                    <a href="<?php echo e(url('blog/delete')); ?>?id=<?php echo e($blog->blog_id); ?>" class="item-btn btn btn-xs btn-danger pull-right">删除</a>
                                    <a href="<?php echo e(url('blog/edit')); ?>?id=<?php echo e($blog->blog_id); ?>" class="item-btn btn btn-xs btn-info pull-right">编辑</a>
                                    <a href="<?php echo e(url('blog/publish')); ?>?id=<?php echo e($blog->blog_id); ?>" class="item-btn btn btn-xs btn-success pull-right">发表</a>
                                    <span class="pull-right"><?php echo e(date('Y-m-d H:i', strtotime($blog->blog_create_time))); ?></span>
                                </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                        <div class="list-item">
                            <div class="pull-left">
                                <button class="btn btn-success btn-sm">批量发表</button>
                                <button class="btn btn-danger btn-sm">批量删除</button>
                            </div>
                            <div class="btn-group pull-right">
                                <?php if($c <= 0): ?>
                                <a href="jacascript:void(0)" class="btn btn-default btn-sm disabled">首页</a>
                                <?php else: ?>
                                <a href="<?php echo e(url('blog/manage/undo')); ?>?p=<?php echo e($c); ?>" class="btn btn-default btn-sm">首页</a>
                                <?php endif; ?>
                                
                                <?php if($p - 1 <= 0): ?>
                                <a href="jacascript:void(0)" class="btn btn-default btn-sm disabled">上一页</a>
                                <?php else: ?>
                                <a href="<?php echo e(url('blog/manage/undo')); ?>?p=<?php echo e($p-1); ?>" class="btn btn-default btn-sm">上一页</a>
                                <?php endif; ?>

                                <?php for($i = -3; $i <= 3; $i++): ?>
                                <?php if($p + $i > 0 && $p + $i <= $c): ?>
                                <?php if($i != 0): ?>
                                <a href="<?php echo e(url('blog/manage/undo')); ?>?p=<?php echo e($p+$i); ?>" class="btn btn-default btn-sm"><?php echo e($p + $i); ?></a>
                                <?php else: ?>
                                <a href="<?php echo e(url('blog/manage/undo')); ?>?p=<?php echo e($p+$i); ?>" class="btn btn-default btn-sm disabled"><?php echo e($p + $i); ?></a>
                                <?php endif; ?>
                                <?php endif; ?>
                                <?php endfor; ?>

                                <?php if($p + 1 > $c): ?>
                                <a href="jacascript:void(0)" class="btn btn-default btn-sm disabled">下一页</a>
                                <?php else: ?>
                                <a href="<?php echo e(url('blog/manage/undo')); ?>?p=<?php echo e($p+1); ?>" class="btn btn-default btn-sm">下一页</a>
                                <?php endif; ?>

                                <?php if($c <= 0): ?>
                                <a href="jacascript:void(0)" class="btn btn-default btn-sm disabled">尾页</a>
                                <?php else: ?>
                                <a href="<?php echo e(url('blog/manage/undo')); ?>?p=<?php echo e($c); ?>" class="btn btn-default btn-sm">尾页</a>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('commen.blogmanage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>