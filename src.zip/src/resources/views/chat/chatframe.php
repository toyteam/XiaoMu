<html>
<head>
    <link href="chatarea.css" rel="stylesheet">
    <meta http-equiv="refresh" content="60">
</head>
<body>
    <div class="chat-area">
                                <div class="chat-diplay-box">

                                <!--分割线-->
                                <div class="char-separater">
                                    以上为历史消息
                                </div>

                                <div class="chat-time-box">
                                    2017-01-25
                                </div>

                                <!--第一个-->
                                <div class="chat-msg-box-left">

                                    <div class="chat-avatar-box-left">
                                    <!--<img src="https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2496451547,4040412945&fm=23&gp=0.jpg" style="width: 60px;"/>-->
                                    </div>
                                    <div class="chat-name-text-left">
                                    <div class="chat-name-box-left">
                                        管理员
                                    </div>

                                    <div class="chat-text-corner-box-left">
                                    </div>

                                    <div class="chat-text-box-left">
                                        hello
                                    </div>
                                    </div>

                                </div>
                                <!--第二个-->
                                <div class="chat-msg-box-left">

                                    <div class="chat-avatar-box-left">
                                        <!--<img src="https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=4178274566,1264226936&fm=23&gp=0.jpg" style="width: 60px;"/>-->
                                    </div>
                                    <div class="chat-name-text-left">
                                    <div class="chat-name-box-left">
                                        管理员
                                    </div>

                                    <div class="chat-text-corner-box-left">
                                    </div>

                                    <div class="chat-text-box-left">
                                        hello！
                                    </div>
                                    </div>

                                </div>
                                <!--第三个-->
                                <div class="chat-msg-box-left">

                                    <div class="chat-avatar-box-left">
                                        <!--<img src="https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=4178274566,1264226936&fm=23&gp=0.jpg" style="width: 60px;"/>-->
                                    </div>
                                    <div class="chat-name-text-left">
                                    <div class="chat-name-box-left">
                                        管理员
                                    </div>

                                    <div class="chat-text-corner-box-left">
                                    </div>

                                    <div class="chat-text-box-left">
                                        在吗？
                                    </div>
                                    </div>

                                </div>
                                <!--第四个-->
                                <div class="chat-msg-box-right">

                                    <div class="chat-avatar-box-right">
                                    <!--<img src="https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=4178274566,1264226936&fm=23&gp=0.jpg" style="width: 60px;"/>-->
                                    </div>
                                    <div class="chat-name-text-right">
                                    <div class="chat-name-box-right">
                                        User
                                    </div>

                                    <div class="chat-text-corner-box-right">
                                    </div>

                                    <div class="chat-text-box-right">
                                        啥事？
                                    </div>
                                    </div>

                                </div>
                            </div>
                    </div>
                    
                </div>
    </body>
</html>